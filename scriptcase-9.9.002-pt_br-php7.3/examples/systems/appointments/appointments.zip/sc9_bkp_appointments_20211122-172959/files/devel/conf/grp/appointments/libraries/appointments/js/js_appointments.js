function chk_selected(){	
		
		var x = document.getElementsByName("opt_status");
		var i;
		var opt = "";
		for (i = 0; i < x.length; i++) {
			if ((x[i].type == "checkbox") && (x[i].checked == true)) {
				if (opt == ""){
					opt = x[i].value
				}
				else{
					opt = opt + "," + x[i].value;
				}			
			}
		}
		
		return opt;
	}