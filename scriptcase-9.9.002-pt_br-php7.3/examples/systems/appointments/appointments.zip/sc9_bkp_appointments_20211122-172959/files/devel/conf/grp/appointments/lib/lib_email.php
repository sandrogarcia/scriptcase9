<?php
//__NM____NM__FUNCTION__NM__//
	function send_email($appointment_id, $copies, $message){
		$subject = "SC Appointments - ID ".$appointment_id." Updated";
		
		sc_mail_send("smtp.mail.yahoo.com", "scriptcase", "Netmake321", "scriptcase@yahoo.com.br", "scriptcase@yahoo.com.br", $subject, $message, "H", $copies, "BCC", "465", "S");

		if ({sc_mail_ok}) {

			//echo "<script>alert('Message sent successfully!');</script>";


		} else { 	

			//sc_error_message("Message not sent!");
		}
		
		
	}
?>