<?php
//__NM____NM__FUNCTION__NM__//

function enable_staff_module() {

	sc_apl_status('form_operator_response','on');
	sc_apl_status('form_staff_profile','on');
	sc_apl_status('grid_operator_tickets','on');
	sc_apl_status('grid_operator_ticketsdetail','on');
	sc_apl_status('grid_operator_ticketsmessage','on');
	sc_apl_status('grid_ticketmessage_show','on');
	sc_apl_status('grid_tickets_unassigned','on');
	sc_apl_status('grid_ticket_show','on');
	sc_apl_status('menu_staff','on'); 
	sc_apl_status('report_tickets_by_operator','on');
	sc_apl_status('report_customer_general','on'); 
	sc_apl_status('report_customer_general_categories','on'); 
	sc_apl_status('report_customer_general_status','on'); 
	sc_apl_status('report_monitor','on'); 
	sc_apl_status('report_monitor_category','on'); 
	sc_apl_status('report_monitor_month_categories','on'); 
	sc_apl_status('report_monitor_operator','on'); 
	sc_apl_status('report_monitor_time_answer','on'); 
	sc_apl_status('report_tickets_by_category','on'); 
	sc_apl_status('report_tickets_by_customer','on'); 
	sc_apl_status('report_tickets_month_categories','on'); 
	sc_apl_status('report_tickets_time_answer','on'); 

}

function enable_admin_module() {

	sc_apl_status('form_categories','on');
	sc_apl_status('form_customer','on');
	sc_apl_status('form_languages','on');
	sc_apl_status('form_kb_articletype','on');
	sc_apl_status('form_kb_categories','on');
	sc_apl_status('grid_tickets_admin','on');
	sc_apl_status('form_canned_message','on');
	sc_apl_status('form_staff','on');
	sc_apl_status('form_systemsettings','on');
	sc_apl_status('form_ticketpriority','on');
	sc_apl_status('form_ticketstatus','on');
	sc_apl_status('form_ticket_email_tpl','on');
	sc_apl_status('grid_customer','on');
	sc_apl_status('grid_canned_message','on');
	sc_apl_status('grid_staff','on');
	sc_apl_status('grid_ticket_email_tpl','on');
	sc_apl_status('menu_admin','on');

}

function enable_customer_module() {

	sc_apl_status('control_ticket_rating','on');
	sc_apl_status('customer_menu','on');
	sc_apl_status('form_customer_edit_profile','on');
	sc_apl_status('form_customer_open_ticket','on');
	sc_apl_status('form_customer_ticket_send_message','on');
	sc_apl_status('form_new_customer','on');
	sc_apl_status('grid_customers_tickets','on');
	sc_apl_status('grid_customer_ticket_flow','on');
	sc_apl_status('report_customer_my_info','on');
}




?>